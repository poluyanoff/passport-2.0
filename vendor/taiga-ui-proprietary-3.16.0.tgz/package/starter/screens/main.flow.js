/* Флоу на общей оболочке (screens/shell): вкладки «О задаче / Решение / Спецификации», Desktop/Mobile, «Начать сначала».
   Тексты вкладок — в screens/flow.content.js, экран — ниже. */
import { mountFlow } from './shell/FlowShell.js';
import { React, T } from './runtime.js';
import { about, spec } from './flow.content.js';

const h = React.createElement;

// Получает {control, resetVersion}. Рисует экраны внутри рамки телефона 375 px.
export function Mobile() {
  return h(T.PageLayout, {platform: 'mobile', header: {title: 'Заголовок экрана'}},
    h(T.CardLarge, {platform: 'mobile', title: 'Первый блок'},
      h(T.Cell, {platform: 'mobile', title: 'Пункт', description: 'Описание'})));
}

mountFlow(document.getElementById('root'), {
  title: 'Название флоу',
  baseUrl: new URL('/', window.location.origin), // куда вернуть адрес при «Начать сначала»
  resetKeys: [],                                  // ключи localStorage, которые нужно очистить при сбросе
  solution: {mobile: Mobile, desktop: null},      // desktop: null → заглушка «появится позже»
  // controls: {initial: 'a', render: ({value, setValue}) => ...},  // свои переключатели над телефоном
  about,                                          // убрать строку — вкладки «О задаче» не будет
  spec                                            // то же для «Спецификации»
});
