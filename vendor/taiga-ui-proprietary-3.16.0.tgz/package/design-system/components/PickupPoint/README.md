# PickupPoint

Информация о пункте выдачи после выбора пина на карте: название, дата доставки, адрес, режим работы, срок хранения. Источник — Figma «Назначение встречи» (ЛК Web и Mobile), сценарий «Доставка в ПВЗ». Сценарий — `meeting.md`.

## Десктоп
Карточка под картой, через 20.
- Фон `background-neutral-1`, радиус 24, поля 20 сверху и снизу, 24 по бокам.
- Заголовок — `heading-5`, справа `ButtonClose` small.
- Строки через 12: иконка 20 `text-tertiary` + текст `ui-m`, между ними 12. Иконки по типу строки (`type`): `date` — `medium/calendar`, `address` — `medium/pin-geo`, `hours` — `medium/clock`, `storage` — `medium/window-clock`.
- Режим работы — несколько строк (`value` массивом).
- Под строками — свой контент (`children`): например `NotificationBanner` с ошибкой загрузки.
- Под карточкой через 32 — кнопка `primary` «Заберу отсюда».

## Мобилка
Содержимое шторки (`BottomSheet` `modal: false`, `inset`) над картой. Боковые поля 16 дает шторка, своих у карточки нет — не оборачивайте ее в отступы.
- Заголовок `ios-heading-m` / `android-heading-m`, 12 сверху и снизу, справа `ButtonClose` small.
- Ячейки: подпись `ui-s` `text-secondary` над значением `body-l`, 8 сверху и снизу.
- Внизу шторки — кнопка L «Заберу отсюда» во всю ширину.

## API
```js
h(TaigaUI.PickupPoint, {
  title: 'Пункт выдачи СДЭК', onClose: close,
  rows: [
    { type: 'date', label: 'Дата доставки', value: 'с 7 до 10 марта', text: 'Дата доставки — с 7 до 10 марта' },
    { type: 'address', label: 'Адрес', value: 'Санкт-Петербург, Невский пр-кт, 15' },
    { type: 'hours', label: 'Режим работы', value: ['Пн – Пт 10:00 – 21:00', 'Сб – Вс 10:00 – 22:00'] },
    { type: 'storage', label: 'Срок хранения', value: '14 дней', text: 'Срок хранения 14 дней' }
  ]
})
```
- Строка: `type`, `icon`, `label` (подпись на мобилке), `value`, `text` (текст строки на десктопе, если отличается от `value`).
- `title`, `rows`, `onClose`, `closeLabel`, `children`, `platform`, `system`, `className`, `style`.
