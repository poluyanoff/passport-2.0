# FlowBoard

Холст доски сценариев: на нем стоят секции со схемой и экранами флоу. Правила — `flow-boards.md`.

## Построение
- Фон `background-base-alt`, поля 160, секции через 160 — отступ между секциями из гайда.
- Секции сверху вниз или в ряд (`direction: 'row'`). Ширина по содержимому: доска шире окна прокручивается вместе со страницей.
- Тема доски — тема страницы (`desktop-day` / `desktop-night`). Экраны на доске — в своих рамках со своим `data-theme`.

## API
```js
h('body', { 'data-theme': 'desktop-day' },
  h(TaigaUI.FlowBoard, null,
    h(TaigaUI.FlowSection, { title: 'User flow', tone: 'contrast' }, ...),
    h(TaigaUI.FlowSection, { title: 'Основной сценарий' }, ...)))
```
- `direction`, `padding`, `gap`, `children`, `className`, `style`.
