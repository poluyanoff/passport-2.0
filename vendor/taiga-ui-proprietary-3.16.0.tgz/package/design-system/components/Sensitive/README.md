# Sensitive

Маска для чувствительных данных: баланс, суммы, номера. Из Taiga UI Proprietary (`tuiSensitive`): поверх скрытого значения — точки цвета текста, ширина маски — по тексту, точки медленно мерцают.

## Когда использовать
- Пользователь скрыл баланс («глаз» рядом с суммой) — суммы на экране под маской.
- Демонстрация экрана, скриншоты в прототипе с реальными на вид суммами.

## Как подключить
- Любой текст — обертка `Sensitive` (`hidden`, по умолчанию `true`).
- Сумма — `Amount` с `sensitive`.
- Бейдж и чип — `sensitive` у `Badge` и `Chip`.
- Баланс в `Panel` — `amountHidden`; переключение — по `amountAction` (иконка `eye-off` → `eye`).

## Поведение
- Маска занимает ровно место текста: верстка не прыгает при показе и скрытии.
- Цвет точек — цвет текста: на темной панели светлые, на цветном бейдже — цвет его текста.
- При `prefers-reduced-motion` точки не мерцают.
- Скринридер читает «Скрыто» (у `Amount` — «Сумма скрыта»), само значение не озвучивается.

## Отличия от кода Тайги
- Нет градиентной маски для градиентного текста — точки цвета текста.
- Нет настроек плотности и параметров текста (`textParams`): для прототипов не нужны.

## Пример
```js
h(TaigaUI.Sensitive, { hidden: hide }, '1\u00A0248\u00A0350\u00A0₽')
h(TaigaUI.Amount, { value: 1248350, sensitive: hide })
h(TaigaUI.Cell, { avatar: 'wallet', title: 'Расчетный счет', description: '•• 4417', right: h(TaigaUI.Amount, { value: 1248350, sensitive: true }) })
h(TaigaUI.Panel, { title: 'Расчетный счет', amount: 1248350, amountHidden: hide, amountAction: { icon: hide ? 'eye' : 'eye-off', label: hide ? 'Показать баланс' : 'Скрыть баланс', onClick: toggle } })
```

## Пропсы
`hidden`, `children`, `ariaLabel`, `className`, `style` (`SensitiveProps` в `index.d.ts`).
