# Skeleton

Заглушка вместо контента, пока он грузится. Из react-kit (`@tui-react/skeleton`). Правила показа — раздел «Загрузка» (`loading.md`).

## Когда использовать
- Текст и блоки своей верстки, у которых нет пропса `skeleton`.
- Экран целиком в загрузке — собираем его из скелетонов по форме будущего контента.

## Когда не использовать
- У компонента есть `skeleton` (`Button`, `Avatar`, `Chip`, `Badge`, `Cell`, `CardLarge`, `Amount` и другие) — включаем его, а не ставим `Skeleton` сверху.
- Короткая загрузка в кнопке или поле — `loading` у компонента или `Loader`.

## Построение
- Цвет — `service-skeleton`, на темном фоне — `service-skeleton-on-dark` (`appearance: 'on-dark'`).
- Пульсация общая со всеми скелетонами экрана: прозрачность 1 → 0.6 → 1. `animation: 'none'` — статичный.
- **Текст** (`variant: 'text'`, по умолчанию) — высота строки берется из класса типографики (`textStyle`, по умолчанию `tui-body-m`), плашка — высотой в кегль, радиус 4. Несколько строк — `lines`, ширина строк 60–100 % (своя — `widths`).
- **Блок** — `width`, `height`, радиус: `rounded` — пилюля, `circular` — круг, `rectangular` — без скругления, свой — `radius`.
- **По размеру элемента** — вложите элемент: он скроется, плашка займет его место.

## Пример
```js
h(TaigaUI.Skeleton, { textStyle: 'tui-heading-5', width: 200 })
h(TaigaUI.Skeleton, { lines: 3 })
h(TaigaUI.Skeleton, { variant: 'circular', width: 40, height: 40 })
```

## Пропсы
`variant`, `textStyle`, `lines`, `widths`, `width`, `height`, `radius`, `margin`, `appearance`, `animation`, `children` — `SkeletonProps` в `index.d.ts`.

## Пробелы
- Плашка текста в ките — 1.2 em, в ДС — 1 em, как у скелетона `Cell`.
- В ките у `circular` радиус 24, в ДС — 50 %.
