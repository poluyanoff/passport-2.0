# SelectAccount

Выбор счета на мобилке: карточка счета, несколько счетов листаются свайпом, по нажатию — шторка «Все счета». Из react-kit (`@tui-react-internal/select-account-mobile`).

## Когда использовать
- Счет списания или зачисления в переводе, оплате, оформлении продукта (WebView).

## Когда не использовать
- Десктоп — `Select` со счетами (`items` с `avatar` и `description`).

## Построение
- **Карточка** — поля 24, радиус 24, фон продукта (`background`: токен градиента `--tui-gradient-brand-*` или цвет; по умолчанию `--tui-gradient-brand-black`).
- Название счета — UI M `text-secondary-on-dark`, сумма — Numbers XL `text-primary-on-dark` через 4. Сумма скрыта — `hidden` у счета или `sensitive` у компонента.
- **Несколько счетов** — шеврон 16 справа, карточки листаются свайпом (`Carousel`, между карточками 8), под ними через 8 — `Pager` M.
- **На всю ширину экрана** — `stagePadding: 16` без своей обертки с полями: карточка стоит в 16 от края, при свайпе карточки уходят в край экрана. Один счет — та же карточка в полях 16.
- **Шторка «Все счета»** (`BottomSheet`) — ячейки: иконка валюты в синем круге, сумма заголовком, название описанием, у выбранного — галочка 24 `text-action`. Выбор закрывает шторку.
- **Скрытые счета** — `hiddenCount`: последняя карточка «Скрытые счета (N)» на `background-neutral-1` с глазом в синем круге; нажатие — `onHiddenClick`.

## Пример
```js
h(TaigaUI.SelectAccount, { value: id, onChange: setId, stagePadding: 16, inline: true, accounts: [
  { id: 1, name: 'Счет Black RUB', amount: 11111.11 },
  { id: 2, name: 'Счет Platinum USD', amount: 520, currency: '$', currencyCode: 'USD', background: 'var(--tui-gradient-brand-platinum)' }] })
```

## Пропсы
`accounts` (`id`, `name`, `amount`, `currency`, `currencyCode`, `background`, `icon`, `hidden`), `value`, `defaultValue`, `onChange`, `sensitive`, `hiddenCount`, `onHiddenClick`, `sheetTitle`, `stagePadding`, `system`, `inline`, `container` — `SelectAccountProps` в `index.d.ts`.

## Пробелы
- Иконка счета с кольцом прогресса (`select-account-icon`, цель накопления) не перенесена.
- Градиент Black в ките — 315°, `#595959 → #333333`; в ДС — токен `--tui-gradient-brand-black` (90°, `#333333 → #5c5c5c`).
- В ките соседняя карточка выглядывает на 32; в ДС карточки идут через 8 без кусочка соседней.
