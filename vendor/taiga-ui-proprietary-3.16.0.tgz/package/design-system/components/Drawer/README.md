# Drawer

Боковая панель поверх страницы. Из react-kit (`@platform-ui/drawer`). Содержимое — свое: компонент дает только панель, подложку и анимацию.

## Когда использовать
- Панель с деталями или фильтрами сбоку, не уводя со страницы. Хронология в панели — `Timeline` S.

## Когда не использовать
- Подтверждение или короткая форма — `Dialog`.
- Мобилка — `BottomSheet`.

## Построение
- Выезжает слева (`from: 'right'` — справа), ширина `calc(100% − 44px)` (своя — `width`).
- Фон `background-base`, подложка `service-backdrop` (`hideOverlay` — без нее).
- Появление и скрытие — сдвиг 250 мс, `linear`.
- Закрывается по подложке и Esc: `onClose('overlay' | 'esc')`.
- `inline` — внутри родителя с `position: relative` (рамка телефона в прототипе).

## Пример
```js
h(TaigaUI.Drawer, { open: open, onClose: close, from: 'right', width: 480 },
  h('div', { style: { padding: 24 } }, h(TaigaUI.Header, { title: 'История изменений' }), h(TaigaUI.Timeline, { size: 's', items: events })))
```

## Пропсы
`open`, `onClose`, `from`, `width`, `hideOverlay`, `inline`, `container`, `zIndex`, `ariaLabel` — `DrawerProps` в `index.d.ts`.

## Пробелы
- Шапка, поля и кнопка закрытия панели в ките не описаны: собирайте из `Header` и `ButtonClose`, поля 24 на десктопе — по правилам отступов ДС.
