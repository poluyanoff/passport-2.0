# FlowRef

Ссылка на компонент ДС рядом с макетом: «TaigaUI: Компонент Toggle». Правила — `flow-boards.md`, «Описание экранов».

## Когда
- Компонент сильно настроен, и разработчик может его не узнать.
- Сложный блок собран из нескольких компонентов ДС — перечислите их, чтобы разработчик не собирал блок с нуля.

## Построение
Плашка `background-accent-2`, текст `text-primary-on-accent-2`, UI S, поля 12 / 8, радиус 12. Имя компонента подчеркнуто, с `href` — ссылка.

## API
```js
h(TaigaUI.FlowRef, { name: 'Toggle' })
h(TaigaUI.FlowRef, { name: ['Header', 'Cell'] })          // «TaigaUI: Компоненты Header, Cell»
h(TaigaUI.FlowRef, { name: 'Segmented', href: 'https://…' })
```
- `name` (строка или массив; или `children`), `href` (строка или массив), `prefix` (по умолчанию «TaigaUI: Компонент»), `className`, `style`.

## Правила
- Имена — как в ДС (`window.TaigaUI`), без своих сокращений.

## Пробелы
- Размеры плашки в Figma не измерены — подобраны по скриншоту гайда.
