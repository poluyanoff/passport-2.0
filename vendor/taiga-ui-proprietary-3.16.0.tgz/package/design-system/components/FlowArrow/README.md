# FlowArrow

Стрелка схемы: переход между элементами сценария или экранами. По Figma TUI Helpers → «Элементы User Flow» → Стрелки. Правила — `flow-boards.md`.

## Виды
| вид | пропсы | когда |
|---|---|---|
| сплошная | — | переход по основному сценарию |
| пунктир | `dashed` | второстепенный переход |
| с подписью | `label` | какому условию удовлетворяет переход |

Подпись — плашка с полями 8, UI M Bold, по центру стрелки. Цвет — по тексту: «Да» — `status-positive`, «Нет» — `status-negative`, другой текст — `background-accent-opposite` (текст `text-primary-on-opposite`). Нужен другой цвет — `tone`: `positive` · `negative` · `neutral`.

Линия 1,5 цвета `text-tertiary`, наконечник — открытая галочка. Длина по умолчанию 80 — отступ между элементами сценария.

## API
```js
h(TaigaUI.FlowArrow)                                   // →, 80
h(TaigaUI.FlowArrow, { label: 'Да' })
h(TaigaUI.FlowArrow, { direction: 'down', dashed: true, length: 120 })
h(TaigaUI.FlowArrow, { label: 'Вариант' })
```
- `direction` (`right` по умолчанию, `left`, `up`, `down`), `length`, `dashed`, `label`, `tone`, `className`, `style`.

## Правила
- В `FlowRow` стрелки между элементами ставятся сами. Свою стрелку (с подписью, пунктиром) поставьте между элементами явно — автоматической там не будет.
- Изогнутая стрелка есть только в ветке «Нет» у `FlowBranch`. Свободных соединителей, как в FigJam, нет: схему стройте рядами.

## Пробелы
- Толщина и цвет линии FigJam, радиус плашки подписи в Figma не видны — подобраны по скриншотам.
