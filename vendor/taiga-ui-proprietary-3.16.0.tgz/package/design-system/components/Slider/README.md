# Slider (`tui-slider`)

Выбор значения или диапазона на дорожке. Из react-kit (`@tui-react/slider`), геометрия и анимации — как в коде.

## Когда использовать
- Калькуляторы: сумма кредита, срок, взнос. Рядом с полем, если значение нужно ввести точно: слайдер под `InputAmount`.
- Диапазон «от и до» в фильтре: цена, сумма операции.
- Настройка с понятной шкалой: громкость, уровень.

## Когда не использовать
- Точное значение без шкалы — `InputAmount`.
- Выбор из 2–5 вариантов — `Segmented` или `ChipGroup`.

## Построение
| | |
|---|---|
| Дорожка | 2, радиус 2, `background-neutral-2`; контейнер 16 |
| Заполнение и ползунок | `background-accent-1`, свой цвет — `color` |
| Ползунок | M 12 (по умолчанию), S 8 |
| Лейбл и значение | `label` слева, значение справа (`formatValue`) — Body S `text-primary`, над дорожкой через 3 |
| Деления (`points`) | штрих 4 × 2 `background-neutral-4`, подписи Body S `text-secondary` на 16 ниже дорожки; у крайних подписи прижаты к краю |
| Вертикальный | `orientation: 'vertical'`, высота `height` (по умолчанию 90); значение сверху, лейбл снизу через 12 |

## Состояния
- **Ховер** (мышь) — ползунок ×1,333 (S ×1,5), `fast`, `productive-standard`.
- **Нажатие** — ореол цвета ползунка 20 % ×2,333 (S ×2,5).
- **Фокус** — обводка 2 `border-focus`. Стрелки — ± шаг, PageUp / PageDown — ± 10 %, Home / End — края.
- **Выключен** (`disabled`) — 56 %.

## Пример
```js
h(TaigaUI.Slider, { label: 'Срок', min: 1, max: 5, value: years, onChange: setYears, formatValue: function (v) { return v + ' г.'; },
  points: [1, 2, 3, 4, 5].map(function (v) { return { value: v, label: String(v) }; }) })
h(TaigaUI.Slider, { label: 'Сумма', min: 0, max: 100000, step: 500, value: [20000, 80000], onChange: setRange,
  formatValue: function (v) { return TaigaUI.formatAmount(v, { decimals: 0, currency: '₽' }); } })
```

## Пропсы
`value`, `defaultValue` (число или `[от, до]`), `onChange`, `onChangeCommit`, `min`, `max`, `step`, `minStepsBetweenThumbs`, `size`, `orientation`, `height`, `color`, `label`, `formatValue`, `showValue`, `points`, `disabled`, `getAriaValueText` — `SliderProps` в `index.d.ts`.

## Пробелы
- Поле со слайдером (`tui-input-slider`, «Формы и поля ввода») отдельным компонентом не сделано: ставьте `InputAmount` и под ним `Slider` через 8.
