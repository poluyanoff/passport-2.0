# InputPhoneAutocomplete

Поле «Номер или имя»: номер по маске или имя, под полем — подсказки из контактов. Из react-kit (`@tui-react/input-phone-autocomplete`). Построено на `InputPhone` и `Autocomplete`: размеры, состояния и список — их.

## Когда использовать
- Перевод по номеру телефона: человек вводит номер или начинает писать имя из контактов.

## Когда не использовать
- Нужен только номер без подсказок — `InputPhone`.

## Поведение
- Цифры, «+» и скобки форматируются маской **+7 921 123-45-67**; «8 900…» при вставке → +7 900….
- Буквы — как есть; подсказки фильтруются по имени. `allowText: false` — только номер.
- Подсказки: ячейка 56, инициалы 40 (`neutral-4`, буквы `text-primary-on-dark`), имя UI M, номер UI S `text-secondary`. Иконка вместо инициалов — `avatar` у контакта.
- Выбор контакта подставляет его номер. `onChange(value, contact)`: номер — `'+7XXXXXXXXXX'`, текст — как введен, `contact` — выбранный контакт или `null`.
- Лейбл по умолчанию — «Номер или имя».

## Пример
```js
h(TaigaUI.InputPhoneAutocomplete, { value: to, onChange: function (v, c) { setTo(v); setContact(c); },
  options: [{ name: 'Василий Пупкин', phone: '+79951234567' }, { name: 'Аркадий Петров', phone: '+79971234567' }] })
```

## Пропсы
`value`, `defaultValue`, `onChange`, `options` (`name`, `phone`, `avatar`), `filter`, `allowText`, `label`, `placeholder`, `hint`, `error`, `size`, `platform`, `system`, `maxHeight`, `disabled` — `InputPhoneAutocompleteProps` в `index.d.ts`.

## Пробелы
- В ките у аватара контакта бывает желтая точка 6 — по стилям не видно, что она значит. В ДС ее нет.
