# Stepper (`tui-stepper`)

Шаги процесса с номером в круге и подписью. Из Taiga UI, геометрия — как в коде.

## Когда использовать
- Длинная десктопная форма или настройка из нескольких частей, где пользователь видит все части сразу и может вернуться к любой: подключение сервиса, настройка интеграции, анкета компании.
- Вертикальный — в боковой колонке рядом с формой.

## Когда не использовать
- Заявки и флоу оформления (ориджинейшен): там прогресс-бар в `Dialog fullscreen`, один вопрос на шаг (`origination.md`).
- Мобилка: шаги не помещаются, там тоже прогресс в аппбаре.
- Хронология событий — `Timeline`.

## Построение
| | Горизонтальный (по умолчанию) | Вертикальный |
|---|---|---|
| Шаг | 44, поля 6 / 16, у первого слева 0 | 64, поля 16, между шагами 8 |
| Номер | круг 32, UI M Bold | так же |
| Подпись | Body M через 12 от круга | Body M, переносится |
| Линия | нет | `connected` — 1 px `border-normal` между кругами |

## Состояния
- **Текущий** — желтый круг `accent-1`, подпись `text-primary`.
- **Обычный** — круг `neutral-1`, номер и подпись `text-action`.
- **Пройден** (`state: 'pass'`) — галочка вместо номера.
- **Ошибка** (`state: 'error'`) — `fixed-color/alert-negative` на `status-negative-pale`.
- **Выключен** (`disabled`) — 56 %, не нажимается.

## Пример
```js
h(TaigaUI.Stepper, { defaultActive: 1, steps: [
  { label: 'Реквизиты', state: 'pass' }, 'Документы', { label: 'Подпись', state: 'error' }, { label: 'Отправка', disabled: true }
] })
h(TaigaUI.Stepper, { orientation: 'vertical', connected: true, active: step, onChange: setStep, steps: ['Компания', 'Руководитель', 'Счета', 'Проверка'] })
```

## Пропсы
`steps` (`label`, `state`, `disabled`), `active`, `defaultActive`, `onChange`, `orientation`, `connected`, `ariaLabel`, `className`, `style` — `StepperProps` в `index.d.ts`.
