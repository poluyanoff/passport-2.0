# FlowFrame и FlowCaption

Экран на доске: подпись, сам макет, заметки для разработки. Правила — `flow-boards.md`, «Описание экранов».

## FlowFrame
- Сверху подпись (`caption`), под ней через 12 — макет (`children`), ниже через 12 — заметки (`notes`: `FlowNote`, `FlowRef`).
- В `FlowRow` ряд выравнивается по центру макета: подписи разной высоты и заметки экран не сдвигают.
- `width` — ширина колонки, по умолчанию по макету.

## FlowCaption
- Без номера — подпись экрана над рамкой: UI S, `text-secondary`.
- С номером (`number`) — блок на всю ширину: подложка `background-neutral-1`, радиус 12; номер — плашка `background-neutral-2` 32, радиус 8, UI M Bold; текст UI M.

## API
```js
h(TaigaUI.FlowFrame, { caption: 'Список устройств' }, screen)
h(TaigaUI.FlowFrame, { number: '1.4', caption: 'Внутренняя проверка займет больше минуты',
  notes: h(TaigaUI.FlowNote, null, 'Через 60 секунд показываем этот экран') }, screen)
h(TaigaUI.FlowCaption, { number: '2.1' }, 'Ошибка сети')
```
- `FlowFrame`: `caption`, `number`, `width`, `notes`, `children`, `className`, `style`.
- `FlowCaption`: `number`, `children` (или `title`), `className`, `style`.

## Правила
- Подписан каждый экран. Похожие экраны различаются подписью: «Ввод суммы», «Ввод суммы — ошибка лимита».
- Макет внутри — со своим `data-theme` платформы.

## Пробелы
- Размеры блока с номером в Figma не измерены — подобраны по скриншоту гайда.
