# Pincode

Ввод ПИН-кода: точки или цифры. Из react-kit (`@tui-react/pincode`), геометрия и анимации — как в коде. Клавиатуру рисует система: ввод идет в скрытое поле.

## Когда использовать
- Вход в приложение или подтверждение действия ПИН-кодом.
- Придумать и повторить новый ПИН-код.

## Когда не использовать
- Код из СМС — `Confirmation`: у него поле, таймер и «Отправить снова».

## Построение
| | Десктоп | Мобилка (`platform: 'mobile'`) |
|---|---|---|
| Ячейка | 22 × 40 | 20 × 36 |
| Между ячейками | 20 | 20 |
| Цифры (`appearance: 'numbers'`) | Heading 3 | iOS Heading L / Android Heading L |
| Точка | 16, `background-neutral-2` | так же |
| Каретка | 2 × 36, радиус 1, `text-primary`, мигает 1 с | так же |

- **Длина** — `length`, по умолчанию 4.
- **Точки** (`dots`, по умолчанию) — введенная становится `text-action` с отскоком (scale 0 → 1,2 → 1, `moderate`).
- **Цифры** (`numbers`) — вместо точки цифра с тем же отскоком.

## Состояния (`state`)
- **idle** — ввод.
- **loading** — проверка: волна вверх на 4, 400 мс, задержка 100 мс на ячейку; ввод выключен.
- **error** — точки и цифры `text-negative`, дрожание ±2 (`moderate`). Через 600 мс — `onAnimationComplete('error')`: очистите значение и верните `idle`.
- **success** — точки и цифры `text-action`; через 600 мс — `onAnimationComplete('success')`.

## Пример
```js
h(TaigaUI.Pincode, { value: pin, onChange: setPin, state: state, autoFocus: true,
  onComplete: function (v) { setState('loading'); verify(v).then(function (ok) { setState(ok ? 'success' : 'error'); }); },
  onAnimationComplete: function (s) { if (s === 'error') { setPin(''); setState('idle'); } } })
h(TaigaUI.Pincode, { platform: 'mobile', appearance: 'numbers', length: 5 })
```

## Пропсы
`length`, `appearance`, `state`, `value`, `defaultValue`, `onChange`, `onComplete`, `onAnimationComplete`, `platform`, `system`, `autoFocus`, `disabled` — `PincodeProps` в `index.d.ts`.

## Пробелы
- Экран входа с цифровой клавиатурой, «Забыли код?» и входом по биометрии в ките не описан — в ДС нет.
- Зациклена ли волна `loading` в ките, по стилям не видно: в ДС волна идет, пока `state: 'loading'`.
