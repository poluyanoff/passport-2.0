# ChartLegend

Легенда графика: что значит каждый цвет, с суммой; нажатием серию можно скрыть. Из react-kit (`@platform-ui/chart`, Legend).

## Когда использовать
- Под графиком с несколькими сериями или частями: `BarChart`, `LinearChart`, круговые.

## Когда не использовать
- Одна серия — подписи хватит в заголовке карточки.

## Построение
- **Пункт** — высота 32: поля 5 / 8, рамка `border-normal`, радиус 4, фон `background-base`, на ховере `background-base-alt`. Текст UI M (`size: 's'` — Body S).
- Точка 8 цвета серии через 8 от текста, значение — UI M Bold через 4 (`wide` — пункт на всю ширину, значение справа).
- Между пунктами 8 (`itemsGap`), перенос на новую строку; `centered` — по центру.
- **Выключенный** пункт — текст `text-secondary`, точка серая. Нажатие включает и выключает (`onChange`, `activeIds`); `flat` — некликабельная.
- `withoutBorders` — без рамки и полей, на ховере текст `text-secondary`.

## Пример
```js
var on = React.useState([0, 1, 2]);
h(TaigaUI.ChartLegend, { items: [{ label: 'Переводы', value: '20 578 ₽' }, { label: 'Транспорт', value: '8 120 ₽' }], activeIds: on[0], onChange: on[1] })
```
Скрытую серию уберите из данных графика сами: передайте 0 вместо значения.

## Пропсы
`items` (`id`, `label`, `value`, `color`), `activeIds`, `defaultActiveIds`, `onChange`, `onItemHover`, `flat`, `toggleable`, `size`, `centered`, `wide`, `withoutBorders`, `itemsGap`, `colors` — `ChartLegendProps` в `index.d.ts`.

## Пробелы
- Цвет точки выключенного пункта в ките не снят — в ДС `text-tertiary`.
- Чекбоксы вместо точек (`withCheckbox`), кнопка «+ / ×» и мобильный вид кита не перенесены.
