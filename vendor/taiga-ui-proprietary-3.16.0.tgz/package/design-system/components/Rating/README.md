# Rating

Оценка иконками: звезды от 1 до 5. Из react-kit (`@tui-react/rating`), геометрия и анимация — как в коде.

## Когда использовать
- Оценка сервиса, чата, курьера, операции после завершения.

## Когда не использовать
- Оценка в ленте чата — виджет `csat` у `ChatMessage`.
- Выбор из вариантов с подписями — `RadioBlock` или `Segmented`.

## Построение
- 5 иконок 40 через 16 (`max`, `iconSize`, `gap`). Иконки меньше 24 не ставим, расстояние — не меньше 8, лучше от 12.
- Иконка — `medium-pragmatic/star-filled` (своя — `icon`). Невыбранная — `background-neutral-4`, выбранная — `background-accent-1` (свои — `color`, `colorSelected`, только токены).
- Выбор нажатием: выбраны все иконки до нажатой. С клавиатуры — стрелки (внутри — `input type="range"`), фокус — рамка `border-focus`.
- При выборе выбранные иконки пружинят: 0.85 → 1.1 → 0.95 → 1 за 0.6 с, от каждой разлетаются 12 искр (`duration-slow`, задержка 50 мс; `sparkles: false` — без них). При нажатии выбранные сжимаются до 0.85.
- Значение по умолчанию — `min` (1). Неизменяемая оценка — `readOnly`.

## Пример
```js
var r = React.useState(5);
h(TaigaUI.Rating, { value: r[0], onChange: r[1], ariaLabel: 'Оцените разговор' })
```

## Пропсы
`value`, `defaultValue`, `onChange`, `min`, `max`, `icon`, `iconSize`, `gap`, `sparkles`, `color`, `colorSelected`, `name`, `readOnly`, `disabled`, `ariaLabel`, `ariaValueText` — `RatingProps` в `index.d.ts`.

## Пробелы
- В ките иконка — Fancy `star` (`TuiIconTdsMediumStar`), в ДС — Pragmatic `star-filled`: Fancy с полупрозрачными слоями не перекрашивается целиком.
- `readOnly` и `disabled` в ките нет, добавлены в ДС.
