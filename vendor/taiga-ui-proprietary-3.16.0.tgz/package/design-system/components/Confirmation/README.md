# Confirmation

Ввод кода из СМС для подтверждения операции. Из Taiga UI Proprietary (`tui-confirmation`), мобильный вид — по шаблону TUI Templates `template-confirmation`.

## Когда использовать
- Подтверждение операции или входа кодом из СМС.
- Десктоп — внутри `Dialog` S с заголовком «Подтверждение» и текстом про номер в `description`.
- Мобилка (WebView) — отдельный экран: `NavigationBar` с крестиком слева и заголовком «Подтверждение» по центру, под ним `Confirmation platform="mobile"`, снизу системная цифровая клавиатура.

## Построение
**Десктоп:**
- Поле L (`Input`), лейбл «Код из СМС», цифровая клавиатура, длина кода — `length` (по умолчанию 4).
- Через 16 — таймер `body-s` `text-secondary` «Отправить снова через 0:44»; после таймера на его месте ссылка «Отправить снова».
- Через 4 — ссылки `Link` 13/20 столбиком: «Не приходит код» (`onNoCode`), «Отмена» (`onCancel`). Без обработчика ссылки нет.

**Мобилка:**
- Текст `body-s` шириной 180 по центру, в 40 от навбара: «Мы отправили код на +7 926 531-12-19» (`phone` или свой `text`).
- Через 24 — поле **180 × 56**, без лейбла, значение по центру.
- Через 20 — flat-кнопка L «Отправить снова»; пока идет таймер — на её месте текст `text-tertiary` «Отправить снова через 0:59».
- Закрыть экран — крестик слева в `NavigationBar` (не «Отмена»).

## Поведение
- Когда введены все цифры, код уходит в `onFilled`. Кнопки «Подтвердить» нет.
- Неверный код — `error` («Неверный код»), поле красное, текст ошибки под полем.
- Неактивных кнопок нет: на время таймера вместо кнопки — текст.
- В номере телефона — неразрывные пробелы и дефисы, чтобы он не переносился.

## Тексты
- «Отправить снова», а не «Отправить еще раз» и не «Повторная отправка» (редполитика, `copy.md`).
- Десктоп: заголовок диалога «Подтверждение», текст «Мы отправили СМС с кодом на +7 …».

## Пример
```js
// Десктоп
h(TaigaUI.Dialog, { open: true, size: 's', title: 'Подтверждение', description: 'Мы отправили СМС с кодом на +7 916 ***-**-04', onClose: close },
  h(TaigaUI.Confirmation, { onFilled: check, onResend: send, onNoCode: help, onCancel: close }))

// Мобилка (WebView)
h('div', null,
  h(TaigaUI.NavigationBar, { large: false, title: 'Подтверждение', titleAlign: 'center', background: 'base', left: 'close', onClose: close }),
  h(TaigaUI.Confirmation, { platform: 'mobile', phone: '+7 926 531-12-19', onFilled: check, onResend: send }))
```

## Пропсы
`platform` (desktop · mobile), `system` (ios · android), `phone`, `text`, `label`, `length`, `timer` (секунды, по умолчанию 60), `value` / `defaultValue` / `onChange`, `onFilled`, `onResend`, `resendLabel`, `onNoCode`, `noCodeLabel`, `onCancel`, `cancelLabel`, `error`, `autoFocus`. Все — в `index.d.ts` (`ConfirmationProps`).
