# Carousel

Карусель: слайды листаются свайпом, стрелками и автопрокруткой. Из react-kit (`@platform-ui/carousel`). Гайда, когда ее использовать, в ките нет — назначение взято из примеров и компонентов, построенных на ней.

## Когда использовать
- Ряд промо-карточек продуктов, которые листаются вбок.
- Выбор счета на мобилке — готовый `SelectAccount`.
- Галерея картинок или слайды онбординга.

## Когда не использовать
- Список, который нужно сравнить целиком, — карточки столбиком или сеткой.
- Действия свайпом по ячейке — `SwipeActions`.

## Построение
- Смена слайда — 400 мс. Свайп листает, если сдвиг больше четверти ширины (не больше 150, свой — `threshold`).
- `perPage` — слайдов на странице, `margin` — отступ между ними, `stagePadding` — кусочек соседних слайдов по бокам (подсказка, что можно листать), `slideStep` — сколько листать за раз.
- `loop` — по кругу (по умолчанию). Без него стрелки на краях выключены.
- **Стрелки** (`withControls`, для десктопа) — `Button` `glass` S, круглые, справа внизу через 16 от краев, между ними 8.
- **Счетчик** (`withCounter`, для мобилки) — «1/12» справа вверху через 16: плашка `background-overlay-glass`, радиус 4, поля 2 / 8, UI 2XS Bold `text-primary-on-dark`.
- **Точки** — отдельный `Pager` под каруселью через 8, с тем же `activeIndex`.
- `autoplay` — сама листает каждые `autoplayTimeout` мс (по умолчанию 5000), стоит, пока на ней курсор.

## Пример
```js
h(TaigaUI.Carousel, { activeIndex: i, onChange: setI, stagePadding: 16, margin: 8, loop: false }, cards)
h(TaigaUI.Pager, { count: cards.length, activeIndex: i })
h(TaigaUI.Carousel, { withCounter: true, borderRadius: 24 }, photos)
```

## Пропсы
`activeIndex`, `defaultActiveIndex`, `onChange`, `perPage`, `slideStep`, `margin`, `stagePadding`, `loop`, `withControls`, `withCounter`, `autoplay`, `autoplayTimeout`, `draggable`, `threshold`, `borderRadius` — `CarouselProps` в `index.d.ts`.

## Отличия от кита и пробелы
- **Стрелки:** в ките — серая платформенная кнопка 32 (`@platform-ui`, частично устаревшая); в ДС — `Button` `glass` S той же формы и размера.
- **Счетчик:** в ките 11/16 Bold, такого стиля в шкале ДС нет — UI 2XS Bold (11/13).
- **Кольцо:** в ките `loop` бесшовный (клоны слайдов); в ДС с последнего слайда карусель отматывается к первому.
- Длительность автопрокрутки и кривая смены слайда в ките по умолчанию не заданы: 5000 мс и `ease`.
- `autoHeight`, `elastic`, `innerPadding` и `outerPadding` не перенесены.
