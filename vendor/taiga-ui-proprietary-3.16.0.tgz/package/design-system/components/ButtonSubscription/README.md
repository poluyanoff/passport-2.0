# ButtonSubscription (`tuiButtonSubscription`)

Кнопка «Доступно с» и логотип подписки после текста. Из Taiga UI Proprietary: оформление обычной кнопки M или L.

## Когда использовать
- Функция или предложение доступны только с подпиской Pro, Premium или Private, и кнопка ведет к оформлению подписки.
- На продуктовой странице, в карточке функции, в пустом состоянии закрытого раздела.
- Просто отметить, что функция входит в подписку, — `Badge` с `appearance: 'pro' | 'premium' | 'private'`, а не кнопка.

## Как работает
- `subscription`: `pro` (по умолчанию) и `private` — черная кнопка `accent-opposite` (как `primary-grayscale`), логотип светлый; `premium` — градиент подписки, текст `text-primary-on-light`.
- Размер `m` — 44 (по умолчанию), `l` — 56. Логотип высотой 16, от текста 10 (M) и 12 (L).
- Текст по умолчанию «Доступно с». Свой — в `label`, коротко и в том же смысле.
- Логотип подставляется сам, для скринридера кнопка звучит как «Доступно с Pro».

## Пример
```js
h(TaigaUI.ButtonSubscription, { subscription: 'pro', onClick: subscribe })
h(TaigaUI.ButtonSubscription, { subscription: 'premium', size: 'l', onClick: subscribe })
```

## Пропсы
`subscription` (`pro` · `premium` · `private`), `size` (`m` · `l`), `label`, `type`, `onClick`, `disabled`, `ariaLabel`, `className`, `style` — `ButtonSubscriptionProps` в `index.d.ts`.

## Пробелы
- Ночная тема: в Taiga кнопка Pro и Private берет `accent-opposite`, в ночи он белый — светлый логотип на нем теряется. Ночной вариант в документации Taiga не показан.
- Градиент Premium — значение из кода Taiga, токена для него у нас нет.
