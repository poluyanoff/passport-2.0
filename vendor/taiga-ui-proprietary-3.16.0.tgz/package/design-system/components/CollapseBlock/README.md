# CollapseBlock

Блок, который сворачивается и раскрывается с анимацией высоты. Из react-kit (`@platform-ui/collapseBlock`). Своего вида у блока нет: кнопку переключения ставит экран.

## Когда использовать
- «Показать полностью» у длинного текста: в свернутом виде видна часть (`minHeight`).
- Блок, который появляется по переключателю или выбору, без сдвига скачком.

## Когда не использовать
- Список вопросов и ответов — `Accordion` (он сам собран на `CollapseBlock`).
- Поля, которые появляются по выбору в заявке, — отдельный шаг (`origination.md`, «Один шаг — один вопрос»).

## Построение
- Анимация высоты — 200 мс (`duration`), можно с задержкой (`delay`). При `prefers-reduced-motion` — без анимации.
- Свернут — высота `minHeight` (по умолчанию 0). При 0 контент удаляется из DOM, `removeCollapsedContent: false` — оставить.
- Свернутый блок с `minHeight: 0` скрыт от скринридера.

## Пример
```js
var c = React.useState(true);
h(TaigaUI.CollapseBlock, { collapsed: c[0], minHeight: 48 }, h('div', { className: 'tui-body-m' }, text)),
h(TaigaUI.Link, { onClick: function () { c[1](!c[0]); } }, c[0] ? 'Показать полностью' : 'Свернуть')
```

## Пропсы
`collapsed`, `minHeight`, `duration`, `delay`, `removeCollapsedContent` — `CollapseBlockProps` в `index.d.ts`.
