# PieChart

Круговая диаграмма: доли целого секторами. Из react-kit (`@platform-ui/chart`, PieChart).

## Когда использовать
- Структура суммы, когда долей мало (до 5–6) и важно соотношение, а не точные значения.

## Когда не использовать
- Нужно показать итог в центре — `RingChart`.
- Много долей или похожие доли — `BarChart`: секторы на глаз не сравнить.

## Построение
- Диаметр 256 (`size`). Первый сектор — сверху, дальше по часовой, без зазоров.
- Цвета — `--tui-chart-categorical-00`, `-01`… по порядку (свои — `color` у пункта или `colors`, только токены).
- Наведение — сектор увеличивается до 115 % за 300 мс; с `getTooltipContent` над ним `Tooltip`. Выделить вручную — `activeIndex`.
- Подписи и суммы — в `ChartLegend` рядом.

## Пример
```js
h(TaigaUI.PieChart, { data: [30, 20, 15, 10, 25], size: 200, getTooltipContent: function (d) { return d.value + '%'; } })
```

## Пропсы
`data` (`value`, `color`), `size`, `activeIndex`, `onActiveChange`, `getTooltipContent`, `onClick`, `colors`, `ariaLabel` — `PieChartProps` в `index.d.ts`.
