# FlowBlock (`user-flow-block`)

Элемент схемы сценария: начало или конец, действие, условие, экран. По Figma TUI Helpers → Layout Tools → «user-flow-block». Правила схемы — `flow-boards.md`.

## Типы (`type`)
| `type` | вид | размер | цвет | значение |
|---|---|---|---|---|
| `entry` | эллипс | 256 × 156 | Helper 5 `#50c0fc`, текст `text-primary-on-dark` | начало или конец сценария, точка входа или выхода |
| `action` (по умолчанию) | прямоугольник, радиус 24 | от 208 × 80, поля 20 | `background-neutral-1-opaque`, текст `text-primary` | действие или процесс |
| `question` | ромб: квадрат 194 под 45°, радиус 24, в рамке 256 × 256 | 256 × 256 | Helper 3 `#9959ed`, текст `text-primary-on-dark` | условие для ветвления |
| `screen` | прямоугольник, радиус 24 | 220 × 312 | Helper Neutral `#484a52`, текст `text-primary-on-dark` | экран, пока без макета |

Текст по центру — iOS Heading M (20 / 24, 700, трекинг 0,38), как в Figma.

## API
```js
h(TaigaUI.FlowBlock, { type: 'entry' }, 'Мои устройства')
h(TaigaUI.FlowBlock, { type: 'question' }, 'Есть точки?')
h(TaigaUI.FlowBlock, { type: 'entry', href: '#auth' }, 'Авторизация')   // связанный сценарий — подчеркнутая ссылка
```
- `type`, `children` (или `label`), `href` / `onClick` — ссылка на связанный сценарий или макет, `className`, `style`.

## Правила
- Ряд блоков со стрелками — `FlowRow`, условие с двумя исходами — `FlowBranch`.
- Блок экрана — пока экрана нет. Готовый экран ставьте макетом в `FlowFrame`.

## Пробелы
- Ночных значений Helper в Figma нет — в ночной теме цвета те же.
- Белый текст на Helper 5 по контрасту ниже 4,5 : 1 — так в Figma.
