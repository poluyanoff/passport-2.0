# RingsChart

Несколько колец прогресса друг в друге: сколько выполнено по каждой цели. Из react-kit (`@platform-ui/chart`, RingsChart).

## Когда использовать
- Прогресс по 2–4 целям или лимитам сразу: накопления, кэшбэк по категориям.

## Когда не использовать
- Одна цель — `ProgressChart` или `ProgressCircle`.
- Доли одного целого — `RingChart`.

## Построение
- Диаметр 256 (`size`), кольца толщиной 10 через 4, внешнее — первое в `data`.
- Дорожка — `--tui-chart-gray-inactive` (`ringBackground`), заполнение — цвет серии со скругленными концами, от верха по часовой. Значение — от 0 до 100, свой максимум — `max` у пункта.
- Заполнение появляется за 450 мс (`disableAnimation` — без анимации). Наведение — свечение кольца цветом серии.
- В центре — `value` (Heading 6) и `label` (UI M `text-secondary`).

## Пример
```js
h(TaigaUI.RingsChart, { data: [{ value: 70 }, { value: 30 }, { value: 55 }], value: '3 цели', label: 'в этом году' })
```

## Пропсы
`data` (`value`, `max`, `color`), `size`, `strokeWidth`, `ringBackground`, `value`, `label`, `disableAnimation`, `activeIndex`, `onActiveChange`, `colors`, `ariaLabel` — `RingsChartProps` в `index.d.ts`.

## Пробелы
- Дорожка в ките — `#ECF1F7`, в ДС — токен `chart-gray-inactive`.
