# FlowRow

Ряд или столбец элементов сценария со стрелками между ними. Правила — `flow-boards.md`.

## Поведение
- Между элементами ставит `FlowArrow` длиной `gap` (по умолчанию 80 — отступ между элементами сценария). Если среди детей уже стоит `FlowArrow`, рядом с ней автоматической стрелки нет.
- Ряд выравнивается по оси сценария: у `FlowBranch` — по центру ромба, у `FlowFrame` — по центру макета (подпись и заметки не сдвигают экран), у остальных — по центру.
- `arrows: false` — без стрелок, элементы через `gap`.
- `direction: 'column'` — сверху вниз, стрелки вниз.

## API
```js
h(TaigaUI.FlowRow, null,
  h(TaigaUI.FlowBlock, { type: 'entry' }, 'Главная'),
  h(TaigaUI.FlowBlock, { type: 'action' }, 'Нажал «Подключить»'),
  h(TaigaUI.FlowArrow, { label: 'Есть счет' }),
  h(TaigaUI.FlowBlock, { type: 'screen' }, 'Выбор счета'))
```
- `direction`, `arrows`, `gap`, `dashed` (пунктир у автоматических стрелок), `children`, `className`, `style`.
