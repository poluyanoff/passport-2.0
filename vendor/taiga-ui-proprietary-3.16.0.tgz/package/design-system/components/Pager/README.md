# Pager

Точки пейджера: на каком слайде или шаге пользователь. Из react-kit (`@tui-react/pager`), геометрия — как в коде.

## Когда использовать
- Под каруселью (`Carousel`), выбором счета, онбордингом — показать, сколько слайдов и какой сейчас.

## Когда не использовать
- Пагинация списка или таблицы — `Pagination`.
- Шаги заявки — прогресс в `Dialog fullscreen`.

## Построение
| | M (по умолчанию) | S |
|---|---|---|
| Точка | 8 | 6 |
| Между точками | 9 | 7 |
| Высота | 20 | 16 |

- Обычная точка — `background-neutral-3`, текущая — `text-action` (свои — `idleColor`, `activeColor`).
- Больше 6 точек — видно окно из 6. У края окна, за которым есть еще точки, крайняя — 50 %, следующая — 75 %. Окно сдвигается за текущей (`fast`, `productive-standard`).
- `lastIcon` / `preLastIcon` — иконка 16 вместо последней или предпоследней точки (например, «+» — добавить карту), цвет как у точки.

## Пример
```js
h(TaigaUI.Pager, { count: slides.length, activeIndex: index })
h(TaigaUI.Pager, { count: 5, activeIndex: 0, size: 's', lastIcon: 'small-pragmatic/plus' })
```

## Пропсы
`count`, `activeIndex`, `size`, `activeColor`, `idleColor`, `lastIcon`, `preLastIcon`, `ariaLabel` — `PagerProps` в `index.d.ts`.
