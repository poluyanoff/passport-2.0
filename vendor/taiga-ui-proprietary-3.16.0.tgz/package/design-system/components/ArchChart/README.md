# ArchChart

Дуга 270°: сколько потрачено или накоплено из лимита. Из react-kit (`@platform-ui/chart`, ArchChart).

## Когда использовать
- Лимит, бюджет, цель: значение и «из скольких» в центре.
- Несколько лимитов — несколько дуг друг в друге; структура одного лимита — сегменты на одной дуге (`stacked`).

## Когда не использовать
- Доли без лимита — `RingChart`.

## Построение
- Диаметр 256, дуга от левого нижнего угла к правому, толщина 10, несколько дуг — через 4.
- Дорожка — `--tui-chart-gray-inactive`, заполнение — цвет серии со скругленными концами, появляется за 450 мс.
- `stacked` — сегменты на одной дуге подряд, доля от `max` (по умолчанию — от суммы).
- В центре — `value` (Heading 6) и `label` (UI M `text-secondary`).

## Пример
```js
h(TaigaUI.ArchChart, { data: [{ value: 62 }], value: '12 400 ₽', label: 'из 20 000 ₽' })
h(TaigaUI.ArchChart, { stacked: true, max: 100, data: [30, 20, 15], value: '65%', label: 'лимита' })
```

## Пропсы
`data`, `stacked`, `max`, `size`, `strokeWidth`, `ringBackground`, `value`, `label`, `disableAnimation`, `colors`, `ariaLabel` — `ArchChartProps` в `index.d.ts`.
