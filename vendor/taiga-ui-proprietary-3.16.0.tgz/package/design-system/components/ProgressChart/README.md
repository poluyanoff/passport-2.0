# ProgressChart

Кольцо прогресса с кнопкой в просвете: доля выполнения и действие рядом. Из react-kit (`@platform-ui/chart`, ProgressChart).

## Когда использовать
- Прогресс к одной цели с действием: пополнить копилку, настроить цель.

## Когда не использовать
- Без действия и в маленьком размере — `ProgressCircle`.
- Несколько целей — `RingsChart`.

## Построение
- Диаметр 256, кольцо 320° от низа по часовой, толщина 10. В просвете справа внизу — кнопка (`button`).
- Дорожка — `--tui-chart-gray-inactive`, заполнение — `--tui-chart-categorical-02` (свое — `color` в `data`), появляется за 450 мс.
- В центре — `value` (Heading 6) и `label` (UI M `text-secondary`).

## Пример
```js
h(TaigaUI.ProgressChart, { data: 60, value: '60%', label: 'накоплено',
  button: h(TaigaUI.Button, { size: 's', appearance: 'primary', icon: 'medium-pragmatic/plus', ariaLabel: 'Пополнить' }) })
```

## Пропсы
`data`, `value`, `label`, `button`, `size`, `strokeWidth`, `ringBackground`, `disableAnimation`, `colors`, `ariaLabel` — `ProgressChartProps` в `index.d.ts`.

## Пробелы
- В ките кнопка — круглая 32, желтая, с иконкой 16. В ДС кнопку передает экран — `Button` S.
