# ButtonShare (`tuiButtonShare`)

Круглая кнопка «Поделиться» 44 с Fancy-иконкой. Из Taiga UI Proprietary: это оформление обычной кнопки, без своего меню.

## Когда использовать
- Поделиться реквизитами, документом, чеком, ссылкой на счет или страницу.
- В шапке карточки, рядом с суммой, в `Panel`, на продуктовой странице.

## Как работает
- Иконка зависит от платформы: десктоп и iOS — `medium/share`, Android — `medium/share-2`. Не задан `system` — берется по теме: `android-*` → `share-2`.
- `appearance`: `secondary` (по умолчанию) или `glass` — поверх фото, карты, пестрого фона.
- Подпись для скринридера и тултип — «Поделиться» (`ariaLabel`).
- Что делает нажатие, решает экран: системное меню «Поделиться» на мобилке (в WebView его рисует приложение), на десктопе — `Dropdown` с каналами или копирование ссылки с `showToast`.

## Пример
```js
h(TaigaUI.ButtonShare, { onClick: share })
h(TaigaUI.ButtonShare, { appearance: 'glass', onClick: share })
// десктоп: меню каналов
h(TaigaUI.Dropdown, { items: ['Скопировать ссылку', 'Отправить на почту', 'Скачать PDF'], onPick: pick }, h(TaigaUI.ButtonShare, {}))
```

## Пропсы
`appearance` (`secondary` · `glass`), `system` (`ios` · `android`), `onClick`, `disabled`, `ariaLabel`, `className`, `style` — `ButtonShareProps` в `index.d.ts`.
